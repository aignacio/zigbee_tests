#ifndef VLO_Rand_Library
#define VLO_Rand_Library

extern int TI_getRandomIntegerFromADC( void );
extern int TI_getRandomIntegerFromVLO( void );

#endif
